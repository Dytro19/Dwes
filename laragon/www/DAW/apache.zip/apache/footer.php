<footer>
    <p>&copy; 2024 Tienda Electrónica. Todos los derechos reservados.</p>
</footer>
